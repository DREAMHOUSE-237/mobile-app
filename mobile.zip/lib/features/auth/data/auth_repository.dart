import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/network/api_client.dart';
import '../../../core/network/api_endpoints.dart';
import '../../../core/storage/secure_storage.dart';
import 'user_model.dart';

// ══════════════════════════════════════════════════════════════════════════════
// AUTH REPOSITORY — Aligné avec auth_service.js du nouveau frontend
// ══════════════════════════════════════════════════════════════════════════════
class AuthRepository {
  final ApiClient _api;
  final SecureStorage _storage;

  AuthRepository(this._api, this._storage);

  // ── LOGIN ─────────────────────────────────────────────────────────────────
  /// Aligne avec login() dans auth_service.js
  /// Le backend retourne : { access: token, user: { user_service_id, ... } }
  Future<UserModel> login({
    required String email,
    required String password,
  }) async {
    final data = await _api.post(
      ApiEndpoints.login,
      data: {'email': email, 'password': password},
    );

    final token    = data['access'] as String;
    final userData = data['user'] as Map<String, dynamic>?;
    final user     = _buildUserFromResponse(token, userData);

    await _storage.saveSession(
      token:      token,
      userId:     user.serviceId,   // user_service_id (User-Service)
      userUuid:   user.uuid,        // user_id JWT (microservices UUID)
      email:      user.email,
      role:       user.role,
      userObject: user.toJson(),
    );

    return user;
  }

  // ── REGISTER CLIENT ───────────────────────────────────────────────────────
  /// Aligne avec registerUser() dans auth_service.js
  /// Champ "tel" (pas "telephone") + role directement
  Future<void> registerClient({
    required String nom,
    required String prenom,
    required String email,
    required String tel,
    required String ville,
    required String region,
    required String password,
    required String role, // 'client' | 'proprietaire'
  }) async {
    await _api.post(ApiEndpoints.register, data: {
      'nom':      nom,
      'prenom':   prenom,
      'email':    email,
      'password': password,
      'tel':      tel,
      'ville':    ville,
      'region':   region,
      'role':     role,
    });
  }

  // ── REGISTER PROPRIO/AGENCE avec CNI (IdentityService) ───────────────────
  /// Aligne avec IdentityService.registerWithIdentity() dans auth_service.js
  /// Inscription proprio/agence en 2 étapes (comme dans Inscription.jsx) :
  /// 1. registerUser → /USER-SERVICE/users/register/
  /// 2. IdentityService.registerWithIdentity → /IDENTITY-SERVICE/identity/submit/
  Future<void> registerWithIdentity({
    required String nom,
    required String prenom,
    required String email,
    required String tel,
    required String ville,
    required String region,
    required String password,
    required String role,
    required File cniRecto,
    required File cniVerso,
  }) async {
    final cleanTel = tel.replaceAll(RegExp(r'[+\s\-]'), '')
        .replaceFirst(RegExp(r'^237'), '');

    // Étape 1 : Créer le compte utilisateur
    await _api.post(ApiEndpoints.register, data: {
      'nom': nom, 'prenom': prenom, 'email': email,
      'password': password, 'tel': cleanTel,
      'ville': ville, 'region': region, 'role': role,
    });

    // Étape 2 : Soumettre la CNI à l'Identity Service
    final identityForm = FormData.fromMap({
      'email':         email,
      'password':      password,
      'requested_role': role,
      'cni_recto': await MultipartFile.fromFile(
          cniRecto.path, filename: 'cni_recto.jpg'),
      'cni_verso': await MultipartFile.fromFile(
          cniVerso.path, filename: 'cni_verso.jpg'),
    });
    await _api.postMultipart(ApiEndpoints.identitySubmit, identityForm);
  }

  // ── LOGOUT ────────────────────────────────────────────────────────────────
  Future<void> logout() => _storage.clearAll();

  Future<UserModel?> getCurrentUser() async {
    final json = await _storage.getUserObject();
    if (json == null) return null;
    return UserModel.fromJson(json);
  }

  Future<bool> isLoggedIn() => _storage.hasValidSession();

  // ── DÉCODAGE JWT + FUSION AVEC response.data.user ─────────────────────────
  /// Reproduit exactement la logique de login() dans auth_service.js :
  /// - user_service_id : response.data.user?.user_service_id || payload.user_service_id
  /// - uuid (microservices) : payload.user_id
  /// - email : payload.email
  /// - role : payload.role
  UserModel _buildUserFromResponse(
    String token,
    Map<String, dynamic>? userData,
  ) {
    try {
      final parts   = token.split('.');
      final payload = jsonDecode(
        utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
      ) as Map<String, dynamic>;

      // Exactement comme dans auth_service.js :
      // const realId = response.data.user?.user_service_id || payload.user_service_id || payload.user_id;
      final serviceId = userData?['user_service_id']?.toString()
          ?? payload['user_service_id']?.toString()
          ?? payload['user_id']?.toString()
          ?? '';

      // UUID pour les microservices = payload.user_id
      final uuid  = payload['user_id']?.toString()  ?? '';
      final email = payload['email']?.toString()     ?? '';
      final role  = payload['role']?.toString()      ?? 'client';

      return UserModel(
        id:        serviceId, // user_service_id → pour appels User-Service
        uuid:      uuid,      // user_id JWT     → pour microservices
        serviceId: serviceId,
        email:     email,
        role:      role,
        nom:       userData?['nom'],
        prenom:    userData?['prenom'],
      );
    } catch (e) {
      return UserModel(
        id:        '',
        uuid:      '',
        serviceId: '',
        email:     userData?['email'] ?? '',
        role:      'client',
      );
    }
  }
}

final authRepositoryProvider = Provider<AuthRepository>((ref) => AuthRepository(
  ref.watch(apiClientProvider),
  ref.watch(secureStorageProvider),
));
