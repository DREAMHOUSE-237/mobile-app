// ══════════════════════════════════════════════════════════════════════════════
// USER MODEL — Aligné avec le payload JWT du nouveau frontend
//
// Deux IDs distincts (comme dans auth_service.js) :
//   - serviceId (user_service_id) → appels /USER-SERVICE/users/users/{id}/profile/
//   - uuid      (user_id JWT)     → headers X-User-Id pour les microservices
// ══════════════════════════════════════════════════════════════════════════════
class UserModel {
  final String id;           // = serviceId (user_service_id)
  final String uuid;         // = user_id JWT (UUID microservices)
  final String serviceId;    // user_service_id explicite
  final String email;
  final String role;
  final String? nom;
  final String? prenom;
  final String? telephone;   // "tel" dans le backend
  final String? ville;
  final String? region;
  final bool isActive;
  final bool identityVerified;

  const UserModel({
    required this.id,
    required this.uuid,
    required this.serviceId,
    required this.email,
    required this.role,
    this.nom,
    this.prenom,
    this.telephone,
    this.ville,
    this.region,
    this.isActive = false,
    this.identityVerified = false,
  });

  String get fullName {
    if (nom != null && prenom != null) return '$nom $prenom';
    if (nom != null) return nom!;
    return email.split('@').first;
  }

  String get displayRole {
    switch (role.toLowerCase()) {
      case 'proprietaire':         return 'Propriétaire';
      case 'pending_proprietaire': return 'Propriétaire (en attente)';
      case 'agence':               return 'Agence Immobilière';
      case 'pending_agent':        return 'Agence (en attente)';
      case 'client':               return 'Client';
      case 'admin':                return 'Administrateur';
      default:                     return role;
    }
  }

  bool get isOwnerRole => [
    'proprietaire', 'pending_proprietaire',
    'agence', 'pending_agent',
  ].contains(role.toLowerCase());

  bool get isAdmin => role.toLowerCase() == 'admin';

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id:               json['id']?.toString()        ?? '',
    uuid:             json['uuid']?.toString()       ?? '',
    serviceId:        json['service_id']?.toString() ?? json['id']?.toString() ?? '',
    email:            json['email']                  ?? '',
    role:             json['role']                   ?? 'client',
    nom:              json['nom'],
    prenom:           json['prenom'],
    telephone:        json['telephone'] ?? json['tel'],
    ville:            json['ville'],
    region:           json['region'],
    isActive:         json['is_active']         ?? false,
    identityVerified: json['identity_verified'] ?? false,
  );

  /// Décodage direct depuis payload JWT
  factory UserModel.fromJwtPayload(Map<String, dynamic> payload) => UserModel(
    id:        payload['user_service_id']?.toString() ?? payload['user_id']?.toString() ?? '',
    uuid:      payload['user_id']?.toString()         ?? '',
    serviceId: payload['user_service_id']?.toString() ?? '',
    email:     payload['email']                       ?? '',
    role:      payload['role']                        ?? 'client',
  );

  Map<String, dynamic> toJson() => {
    'id':               id,
    'uuid':             uuid,
    'service_id':       serviceId,
    'email':            email,
    'role':             role,
    'nom':              nom,
    'prenom':           prenom,
    'telephone':        telephone,
    'ville':            ville,
    'region':           region,
    'is_active':        isActive,
    'identity_verified': identityVerified,
  };

  UserModel copyWith({
    String? nom, String? prenom, String? telephone,
    String? ville, String? region,
    bool? isActive, bool? identityVerified,
  }) => UserModel(
    id:               id,
    uuid:             uuid,
    serviceId:        serviceId,
    email:            email,
    role:             role,
    nom:              nom              ?? this.nom,
    prenom:           prenom          ?? this.prenom,
    telephone:        telephone       ?? this.telephone,
    ville:            ville           ?? this.ville,
    region:           region          ?? this.region,
    isActive:         isActive        ?? this.isActive,
    identityVerified: identityVerified ?? this.identityVerified,
  );
}
