import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/network/api_client.dart';
import '../../../core/network/api_endpoints.dart';
import 'comment_model.dart';

// ══════════════════════════════════════════════════════════════════════════════
// COMMENT REPOSITORY — Équivalent de CommentService dans auth_service.js
// ══════════════════════════════════════════════════════════════════════════════
class CommentRepository {
  final ApiClient _api;
  CommentRepository(this._api);

  Future<List<CommentModel>> getByPublication(String pubId) async {
    final data = await _api.get(ApiEndpoints.comments(pubId));
    if (data is List) {
      return data.map((e) => CommentModel.fromJson(e)).toList();
    }
    return [];
  }

  Future<CommentModel> create({
    required String publicationId,
    required String contenu,
    String? parentId,
  }) async {
    final data = await _api.post(ApiEndpoints.createComment, data: {
      'publication_id': publicationId,
      'contenu': contenu,
      if (parentId != null) 'parent_id': parentId,
    });
    return CommentModel.fromJson(data as Map<String, dynamic>);
  }

  Future<void> like(String commentId) =>
      _api.post(ApiEndpoints.likeComment(commentId));

  Future<void> delete(String commentId) =>
      _api.delete(ApiEndpoints.deleteComment(commentId));
}

final commentRepositoryProvider = Provider<CommentRepository>((ref) {
  return CommentRepository(ref.watch(apiClientProvider));
});

// ── Provider commentaires par publication ─────────────────────────────────────
final commentsProvider = FutureProvider.family
    .autoDispose<List<CommentModel>, String>((ref, pubId) {
  return ref.watch(commentRepositoryProvider).getByPublication(pubId);
});
